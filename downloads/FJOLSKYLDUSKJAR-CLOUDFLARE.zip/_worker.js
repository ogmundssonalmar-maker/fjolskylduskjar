// src/calendar.js
var google = "https://www.googleapis.com/calendar/v3";
async function readCalendar(env, now = /* @__PURE__ */ new Date()) {
  const ids = [...new Set((env.GOOGLE_CALENDAR_IDS || "").split(",").map((id) => id.trim()).filter(Boolean))];
  if (!ids.length) return { connected: false, events: [] };
  const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    body: new URLSearchParams({
      grant_type: "refresh_token",
      client_id: env.GOOGLE_CLIENT_ID,
      client_secret: env.GOOGLE_CLIENT_SECRET,
      refresh_token: env.GOOGLE_REFRESH_TOKEN
    })
  });
  if (!tokenResponse.ok) throw new Error("Google OAuth failed");
  const { access_token: token } = await tokenResponse.json();
  if (!token) throw new Error("Google OAuth returned no token");
  const today = now.toISOString().slice(0, 10);
  const timeMin = today + "T00:00:00Z";
  const timeMax = new Date(Date.parse(timeMin) + 45 * 864e5).toISOString();
  const headers = { Authorization: "Bearer " + token };
  const events = /* @__PURE__ */ new Map();
  for (const id of ids) {
    const url = new URL(google + "/calendars/" + encodeURIComponent(id) + "/events");
    url.search = new URLSearchParams({
      timeMin,
      timeMax,
      singleEvents: "true",
      orderBy: "startTime",
      maxResults: "250",
      timeZone: "Atlantic/Reykjavik"
    });
    do {
      const response2 = await fetch(url, { headers });
      if (!response2.ok) throw new Error("Google Calendar request failed");
      const page = await response2.json();
      for (const item of page.items || []) {
        if (item.status === "cancelled" || !item.start || !item.end) continue;
        const start = item.start.date || new Date(item.start.dateTime).toISOString().slice(0, 10);
        const end = new Date(Date.parse(item.end.date || item.end.dateTime) - 1).toISOString().slice(0, 10);
        const time = item.start.dateTime ? new Date(item.start.dateTime).toISOString().slice(11, 16) : void 0;
        const occurrence = item.originalStartTime || item.start;
        const key = item.iCalUID ? JSON.stringify([item.iCalUID, occurrence.date || new Date(occurrence.dateTime).toISOString()]) : id + ":" + item.id;
        events.set(key, {
          start,
          end: end < start ? start : end,
          time,
          title: item.summary || "Vi\xF0bur\xF0ur",
          type: "dagatal",
          note: item.location || ""
        });
      }
      if (!page.nextPageToken) break;
      url.searchParams.set("pageToken", page.nextPageToken);
    } while (true);
  }
  return { connected: true, events: [...events.values()] };
}

// src/household.js
var response = (body, status = 200) => Response.json(body, {
  status,
  headers: { "Cache-Control": "private, no-store" }
});
function validState(state) {
  return Number.isSafeInteger(state?.version) && state.version >= 0 && Array.isArray(state.tasks) && state.tasks.length <= 250 && state.tasks.every((task) => typeof task?.name === "string" && task.name.trim().length > 0 && task.name.length <= 180 && typeof task.done === "boolean") && Array.isArray(state.meals) && state.meals.length === 7 && state.meals.every((meal) => typeof meal?.name === "string" && meal.name.trim().length > 0 && meal.name.length <= 180 && typeof meal.day === "string" && meal.day.length <= 4 && (meal.minutes === null || Number.isInteger(meal.minutes) && meal.minutes >= 0 && meal.minutes <= 1440) && typeof meal.url === "string" && meal.url.length <= 1024 && (meal.url === "" || URL.canParse(meal.url) && ["https:", "http:"].includes(new URL(meal.url).protocol)));
}
async function household(request, env) {
  const { pathname } = new URL(request.url);
  if (pathname === "/api/calendar" && request.method === "GET") {
    try {
      return response(await readCalendar(env));
    } catch {
      return response({ error: "Ekki n\xE1\xF0ist \xED Google Calendar." }, 502);
    }
  }
  if (pathname !== "/api/household") return response({ error: "Sl\xF3\xF0 fannst ekki." }, 404);
  if (!env.DB) return response({ error: "Gagnagrunnur hefur ekki veri\xF0 tengdur." }, 503);
  if (request.method === "GET") {
    const state2 = await env.DB.prepare("SELECT version, tasks, meals FROM household WHERE id = 1").first();
    return response(state2 ? {
      version: state2.version,
      tasks: JSON.parse(state2.tasks),
      meals: JSON.parse(state2.meals)
    } : { version: 0 });
  }
  if (request.method !== "PUT") return response({ error: "A\xF0fer\xF0 \xF3heimil." }, 405);
  if (request.headers.get("Origin") !== new URL(request.url).origin || request.headers.get("Content-Type")?.split(";")[0] !== "application/json") {
    return response({ error: "Bei\xF0ni \xF3heimil." }, 403);
  }
  const input = await request.text();
  if (input.length > 7e4) return response({ error: "Bei\xF0ni er of st\xF3r." }, 413);
  let state;
  try {
    state = JSON.parse(input);
  } catch {
    return response({ error: "\xD3gild bei\xF0ni." }, 400);
  }
  if (!validState(state)) return response({ error: "\xD3gild g\xF6gn." }, 400);
  const tasks = JSON.stringify(state.tasks.map(({ name, done }) => ({ name, done })));
  const meals = JSON.stringify(state.meals.map(({ day, name, minutes, url }) => ({ day, name, minutes, url })));
  const statement = state.version === 0 ? env.DB.prepare("INSERT INTO household VALUES (1, 1, ?, ?) ON CONFLICT(id) DO NOTHING").bind(tasks, meals) : env.DB.prepare("UPDATE household SET version = version + 1, tasks = ?, meals = ? WHERE id = 1 AND version = ?").bind(tasks, meals, state.version);
  const result = await statement.run();
  return result.meta.changes ? response({ version: state.version + 1 }) : response({ error: "Breyting var vistu\xF0 \xFAr \xF6\xF0ru t\xE6ki." }, 409);
}

// src/pages-upload.js
var encoder = new TextEncoder();
var privateHeaders = {
  "Cache-Control": "private, no-store",
  "X-Robots-Tag": "noindex, nofollow",
  "X-Content-Type-Options": "nosniff",
  "Content-Security-Policy": "frame-ancestors 'none'; base-uri 'none'; object-src 'none'"
};
async function matches(request, password) {
  const match = /^Basic ([A-Za-z0-9+/=]+)$/i.exec(request.headers.get("Authorization") ?? "");
  if (!match) return false;
  let provided;
  try {
    provided = atob(match[1]);
  } catch {
    return false;
  }
  const [actual, expected] = await Promise.all([
    crypto.subtle.digest("SHA-256", Uint8Array.from(provided, (character) => character.charCodeAt(0))),
    crypto.subtle.digest("SHA-256", encoder.encode("heimili:" + password))
  ]);
  const left = new Uint8Array(actual);
  const right = new Uint8Array(expected);
  let difference = 0;
  for (let i = 0; i < left.length; i++) difference |= left[i] ^ right[i];
  return difference === 0;
}
var pages_upload_default = {
  async fetch(request, env) {
    if (!env.APP_PASSWORD) {
      return new Response("Heimilisskj\xE1rinn b\xED\xF0ur uppsetningar lykilor\xF0s.", {
        status: 503,
        headers: privateHeaders
      });
    }
    if (!await matches(request, env.APP_PASSWORD)) {
      return new Response("Skr\xE1\xF0u \xFEig inn til a\xF0 opna heimilisskj\xE1inn.", {
        status: 401,
        headers: { ...privateHeaders, "WWW-Authenticate": 'Basic realm="Heima hja okkur", charset="UTF-8"' }
      });
    }
    const { pathname } = new URL(request.url);
    if (pathname === "/api" || pathname.startsWith("/api/")) return household(request, env);
    const assetRequest = new Request(request);
    assetRequest.headers.delete("Authorization");
    const asset = await env.ASSETS.fetch(assetRequest);
    const response2 = new Response(asset.body, asset);
    for (const [key, value] of Object.entries(privateHeaders)) response2.headers.set(key, value);
    return response2;
  }
};
export {
  pages_upload_default as default
};
